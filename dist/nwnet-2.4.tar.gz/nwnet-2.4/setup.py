#!/usr/bin/env python

from distutils.core import setup

setup(name = 'nwnet',
	version = '2.4',
	author = 'Jeremy Smith',
	author_email = 'j-smith@eecs.berkeley.edu',
	url = 'http://ink.eecs.berkeley.edu',
	py_modules = ['nwnet'],
	)
